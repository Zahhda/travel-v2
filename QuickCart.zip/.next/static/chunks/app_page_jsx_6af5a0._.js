(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_jsx_6af5a0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_jsx_6af5a0._.js",
  "chunks": [
    "static/chunks/_7178e0._.js",
    "static/chunks/node_modules_next_acaa1c._.js"
  ],
  "source": "dynamic"
});
