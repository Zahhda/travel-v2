(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_my-bookings_page_jsx_b0bacf._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_my-bookings_page_jsx_b0bacf._.js",
  "chunks": [
    "static/chunks/_cbe04a._.js",
    "static/chunks/node_modules_next_eec718._.js"
  ],
  "source": "dynamic"
});
