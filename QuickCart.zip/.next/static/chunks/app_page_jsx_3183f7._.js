(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_jsx_3183f7._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_jsx_3183f7._.js",
  "chunks": [
    "static/chunks/_f11571._.js",
    "static/chunks/node_modules_next_eec718._.js"
  ],
  "source": "dynamic"
});
