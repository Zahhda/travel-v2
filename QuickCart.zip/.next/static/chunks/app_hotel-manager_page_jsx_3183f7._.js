(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_hotel-manager_page_jsx_3183f7._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_hotel-manager_page_jsx_3183f7._.js",
  "chunks": [
    "static/chunks/_831ad4._.js",
    "static/chunks/node_modules_next_acaa1c._.js"
  ],
  "source": "dynamic"
});
