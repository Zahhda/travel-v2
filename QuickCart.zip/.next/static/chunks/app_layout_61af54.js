(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_61af54.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_61af54.js",
  "chunks": [
    "static/chunks/[root of the server]__3a14ec._.css",
    "static/chunks/node_modules_c53eeb._.js",
    "static/chunks/_a6a9a9._.js",
    "static/chunks/node_modules_@clerk_nextjs_dist_esm_app-router_65453d._.js"
  ],
  "source": "dynamic"
});
