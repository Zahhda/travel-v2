const CHUNK_PUBLIC_PATH = "server/app/api/user/data/route.js";
const runtime = require("../../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/node_modules_2f3fae._.js");
runtime.loadChunk("server/chunks/[root of the server]__746bb3._.js");
runtime.loadChunk("server/chunks/node_modules_@clerk_nextjs_dist_esm_server_fs_middleware-location_94c254.js");
runtime.loadChunk("server/chunks/_39f216._.js");
runtime.getOrInstantiateRuntimeModule("[project]/.next-internal/server/app/api/user/data/route/actions.js [app-rsc] (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/user/data/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
